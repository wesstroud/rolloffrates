
pip install -r requirements.txt

python -m playwright install chromium

echo "Installation complete. You can now run the scraper with 'python final_scraper.py'"
